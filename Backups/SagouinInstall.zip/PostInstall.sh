#!/bin/bash

echo " "
echo "************************************"
echo "Script PostInstall...Debian 8.4"
echo "version 20160405"
echo "Auteur/compositeur : Olivier GOMEZ"
echo "************************************"
echo " "
echo "Menu : Choisir option d'installation"
echo "1 : Deb Basique"
echo "2 : Deb Basique+GDM3"
echo "3 : DebVirtu (2+virtualbox)"
echo "4 : Menu suivant"
echo " "
read 
echo "reponse : $REPLY"

function Install () {
	if [ $(dpkg-query -W -f='${Status}' $1 2>/dev/null | grep -c "ok installed") -eq 0 ];
	then
		echo "Install $1"
		echo "root requis pour installer"
		if [ $EUID -ne 0 ]; 
		then
			echo "$0 is not running as root. Aborting."
			echo "Connecter en root? y/n"
			read
			if [ "$REPLY" == "y" ]
			then
				su - -c "apt-get install $1"
			else
				apt-get install $1
			fi
		fi
	else	
		echo "$1 installé"
	fi
}

if [ "$REPLY" == "4" ]
then
	echo "exec du script n°2"
	./SourcesInstall.sh
fi

if [ "$REPLY" == "2" ] || [ "$REPLY" == "3" ];
then
	Install "gdm3"
	Install "terminator"
fi

if [ "$REPLY" == "3" ];
then 
	Install "virtualbox"
	echo "Download ISO? y/n"
	echo " "
	read
	echo "reponse $REPLY"
	if [ "$REPLY" == "y" ];
	then
		echo "wget deb8.4 netinst"
		#wget -c http://caesar.acc.umu.se/debian-cd/8.4.0/amd64/iso-cd/debian-8.4.0-amd64-netinst.iso
	fi 
fi	



#########
#Annexe
echo "Voir les softs annexes ? y/n"
read
if [ "$REPLY" == "y" ]
then
	echo " "
	echo "installer geany ? y/n"
	echo " "
	read
	if [ "$REPLY" == "y" ];
	then
		Install "geany"
		echo "purge gedit"
		#apt-get autoremove gedit
		#apt-get purge gedit
	fi

	echo " "
	echo "installer flash ? y/n"
	echo "WARNING : NONFREE"
	echo " "
	read
	if [ "$REPLY" == "y" ];
	then
		Install "flashplugin-nonfree"
	fi
fi
#########


#Raccourcis
#
#Packet xXx installé?
#if [ $(dpkg-query -W -f='${Status}' xXx 2>/dev/null | grep -c "ok installed") -eq 0 ];
#
#########
#todo
#
