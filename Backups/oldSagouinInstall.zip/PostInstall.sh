#!/bin/bash

echo " "
echo "************************************"
echo "Script PostInstall...Debian 8.4"
echo "version 20160403v2"
echo "Auteur/compositeur : Olivier GOMEZ"
echo "************************************"
echo " "
echo "Menu : Choisir option d'installation"
echo "1 : Deb Basique"
echo "2 : Deb Basique+GDM3"
echo "3 : DebVirtu (2+virtualbox)"
echo "4 : Menu suivant"
echo " "
read 
echo "reponse : $REPLY"

function Install () {
	if [ $(dpkg-query -W -f='${Status}' $1 2>/dev/null | grep -c "ok installed") -eq 0 ];
	then
		echo "Install $1"
		#apt-get install $1
	else	
		echo "$1 installé"
	fi
}


if [ "$REPLY" == "2" ] || [ "$REPLY" == "3" ];
then
	Install "gdm3"
	Install "terminator"
fi

if [ "$REPLY" == "3" ];
then 
	Install "virtualbox"
	echo "Download ISO? y/n"
	echo " "
	read
	echo "reponse $REPLY"
	if [ "$REPLY" == "y" ];
	then
		echo "wget deb8.4 netinst"
		#wget -c http://caesar.acc.umu.se/debian-cd/8.4.0/amd64/iso-cd/debian-8.4.0-amd64-netinst.iso
	fi 
fi	


if [ "$REPLY" == "8" ]
then
	echo "exec du script n°2"
	/bin/bash /home/test/Documents/Prog/PostInstall.sh
fi
#########
#Annexe
echo "Voir les softs annexes ? y/n"
read
if [ "$REPLY" == "y" ]
then
	echo " "
	echo "installer geany ? y/n"
	echo " "
	read
	if [ "$REPLY" == "y" ];
	then
		Install "geany"
		echo "purge gedit"
		#apt-get autoremove gedit
		#apt-get purge gedit
	fi

	echo " "
	echo "installer flash ? y/n"
	echo "WARNING : NONFREE"
	echo " "
	read
	if [ "$REPLY" == "y" ];
	then
		Install "flashplugin-nonfree"
	fi
fi


#Raccourcis
#
#Packet xXx installé?
#if [ $(dpkg-query -W -f='${Status}' xXx 2>/dev/null | grep -c "ok installed") -eq 0 ];
#
#########
#todo
#
#modification du source.list si besoin (non-free)
#
