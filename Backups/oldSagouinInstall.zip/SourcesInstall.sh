n
#!/bin/bash
#PostInstall

echo " "
echo "************************************"
echo "Script PostInstall...Debian 8.4"
echo "version 20160403"
echo "Auteur/compositeur : Olivier GOMEZ"
echo "************************************"
echo " "
echo "Menu second"
echo "1 : Modif. sources.list"
read
echo " "

if [ "$REPLY" == "1" ]
then 
	if [  $(diff -q /etc/apt/sources.list /home/test/Documents/Prog/Docs/sources.list 2>/dev/null | grep -c "différents") -eq 1 ];
	then	
		echo "spaparay"
		cp /home/test/Documents/Prog/Docs/sources.list /etc/apt/sources.list
	else 
		echo "sparay"
	fi
fi 



